CREATE DATABASE  IF NOT EXISTS `statement_info` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `statement_info`;
-- MySQL dump 10.13  Distrib 5.6.11, for Win32 (x86)
--
-- Host: localhost    Database: statement_info
-- ------------------------------------------------------
-- Server version	5.6.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cust_info`
--

DROP TABLE IF EXISTS `cust_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cust_info` (
  `Customer_id` int(10) NOT NULL DEFAULT '0',
  `ACCOUNTNUMBER` varchar(100) DEFAULT NULL,
  `INTERNALREF` varchar(100) DEFAULT NULL,
  `FORNAME` varchar(100) DEFAULT NULL,
  `SURNAME` varchar(100) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `ADDRESS1` varchar(100) DEFAULT NULL,
  `ADDRESS2` varchar(100) DEFAULT NULL,
  `ADDRESS3` varchar(100) DEFAULT NULL,
  `ADDRESS4` varchar(100) DEFAULT NULL,
  `POSTCODE` varchar(100) DEFAULT NULL,
  `TELEPHONE` varchar(100) DEFAULT NULL,
  `FAX` varchar(100) DEFAULT NULL,
  `EMAIL` varchar(100) DEFAULT NULL,
  `PROFILE` varchar(100) DEFAULT NULL,
  `MARKETING` varchar(100) DEFAULT NULL,
  `MESSAGE1` varchar(100) DEFAULT NULL,
  `MESSAGE2` varchar(100) DEFAULT NULL,
  `MESSAGE3` varchar(100) DEFAULT NULL,
  `CUSSERVICENUMBER` varchar(100) DEFAULT NULL,
  `COLLECTOUTSIDENA` varchar(100) DEFAULT NULL,
  `SELFSERVICE` varchar(100) DEFAULT NULL,
  `TELEPHONEBANKING` varchar(100) DEFAULT NULL,
  `WEBSITE` varchar(100) DEFAULT NULL,
  `CORPADD1` varchar(100) DEFAULT NULL,
  `CORPADD2` varchar(100) DEFAULT NULL,
  `CORPADD3` varchar(100) DEFAULT NULL,
  `CORPADD4` varchar(100) DEFAULT NULL,
  `CORPPOST` varchar(100) DEFAULT NULL,
  `locale` varchar(5) DEFAULT NULL,
  `LatePaymentFee` decimal(10,4) DEFAULT NULL,
  `MinimumFinanceCharge` decimal(10,4) DEFAULT NULL,
  `Country` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_info`
--

LOCK TABLES `cust_info` WRITE;
/*!40000 ALTER TABLE `cust_info` DISABLE KEYS */;
INSERT INTO `cust_info` VALUES (1,'4555-9999-0001','XNS0150150_4282620_030119249','Sam','Shi','1937-05-22','1511 Lombard St.','San Francisco','CA','','94111','415-456-9876','','samshi@bi.com','','','','','','1-800-555-5550','(650) 555-5551','1-877-555-5552','1-800-555-5555','www.sfwealth.com','951 Mariners Island Boulevard','San Mateo','CA','USA','94404','en_US',39.0000,0.5000,'United States'),(2,'4555-9999-0002','XNS0150150_4282620_030119250','Bob','Baker','1974-07-14','1011 Montcalm St.','San Francisco','CA','','94110','415-234-5432','415-234-5555','bob@business.com','','','','','','1-800-555-5550','(650) 555-5551','1-877-555-5552','1-800-555-5555','www.sfwealth.com','951 Mariners Island Boulevard','San Mateo','CA','USA','94404','en_US',39.0000,0.5000,'United States'),(3,'4555-9999-0003','XNS0150150_4282620_030119251','Pete','Powers','1980-07-30','17691 Lombard St.','San Francisco','CA','','94123','415-987-4321','415-987-4433','pete@power.com','','','','','','1-800-555-5550','(650) 555-5551','1-877-555-5552','1-800-555-5555','www.sfwealth.com','951 Mariners Island Boulevard','San Mateo','CA','USA','94404','en_US',39.0000,0.5000,'United States'),(4,'4555-9999-0004','XNS0150150_4282620_030119252','Abigail','Adams','1963-01-05','130 Locust St.','San Francisco','CA','','94118','415-756-4839','','audrey@audited.com','','','','','','1-800-555-5550','(650) 555-5551','1-877-555-5552','1-800-555-5555','www.sfwealth.com','951 Mariners Island Boulevard','San Mateo','CA','USA','94404','en_US',39.0000,0.5000,'United States'),(5,'4555-9999-0005','XNS0150150_4282620_030119205','Charlie','Jones','1965-08-16','46 Bow Lane','London','UK','','EC4M 9DL','207-246-1234','','','','','','','','1-800-555-5550','207-555-5551','1-877-555-5552','1-800-555-5555','www.sfwealth.co.uk','Suite 201 - 95 Mural St.','London','UK','United Kingdom','EC4M 9DL','en_GB',39.0000,0.5000,'United Kingdom'),(6,'4555-9999-0006','XNS0150150_4282620_030119206','Isabelle','Scholes','1980-09-17','46 Bow Lane','London','UK','','EC4M 9DL','207-246-5678','207-234-5555','ischoles@bowlane.co.uk','','','','','','1-800-555-5550','207-555-5551','1-877-555-5552','1-800-555-5555','www.sfwealth.co.uk','Suite 201 - 95 Mural St.','London','UK','United Kingdom','EC4M 9DL','en_GB',39.0000,0.5000,'United Kingdom'),(7,'4555-9999-0007','XNS0150150_4282620_030119207','Rachel','Lee','1984-07-30','8 Temasek Boulevard','Singapore','SG','','38988','65-2987-4321','65-2987-4322','rlee@temasek.com.sg','','','','','','1-800-555-5550','2555-5551','1-877-555-5552','1-800-555-5555','www.sfwealth.com.sg','Suite 201 - 95 Mural St.','Suntech Tower','SG','Singapore','38988','en_SG',39.0000,0.5000,'Singapore'),(8,'4555-9999-0008','XNS0150150_4282620_030119208','Whitney','Wong','1973-01-05','10 Stanley Street','Central','HK','','','85-2323-1234','85-2323-1235','whitney.wong@stanley.com.hk','','','','','','1-800-555-5550','2555-5551','1-877-555-5552','1-800-555-5555','www.sfwealth.com.hk','Suite 201 - 95 Mural St.','Central','HK','Hong Kong','','en_HK',39.0000,0.5000,'Hong Kong');
/*!40000 ALTER TABLE `cust_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-30  9:58:48
